import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
})

export async function POST(req: NextRequest) {
  try {
    const { business, topic, platforms, tone } = await req.json()

    if (!business || !topic || !platforms?.length) {
      return NextResponse.json({ error: 'Campos obrigatórios faltando' }, { status: 400 })
    }

    const prompt = `Você é um especialista em marketing digital e copywriting para redes sociais brasileiro.

Negócio/produto: ${business}
Assunto do post: ${topic}
Tom de voz: ${tone}
Redes sociais: ${platforms.join(', ')}

Crie um post otimizado para cada rede social solicitada. Adapte o tamanho, linguagem, hashtags e emojis para cada plataforma:
- Instagram: visual, emojis, hashtags relevantes, CTA engajador
- LinkedIn: profissional, mais longo, foco em valor e insights
- Twitter/X: conciso, direto, máximo 280 caracteres, hashtags estratégicas

Responda APENAS em JSON válido, sem markdown ou texto adicional:
{
  "posts": [
    { "platform": "Instagram", "content": "...", "chars": 0 },
    { "platform": "LinkedIn", "content": "...", "chars": 0 },
    { "platform": "Twitter/X", "content": "...", "chars": 0 }
  ]
}`

    const message = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1200,
      messages: [{ role: 'user', content: prompt }],
    })

    const text = message.content
      .filter(b => b.type === 'text')
      .map(b => (b as { type: 'text'; text: string }).text)
      .join('')

    const clean = text.replace(/```json|```/g, '').trim()
    const data = JSON.parse(clean)

    // Add char counts
    data.posts = data.posts.map((p: { platform: string; content: string }) => ({
      ...p,
      chars: p.content.length,
    }))

    return NextResponse.json(data)
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'Erro ao gerar posts' }, { status: 500 })
  }
}
