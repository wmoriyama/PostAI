'use client'

import { useState } from 'react'
import styles from './page.module.css'

const PLATFORMS = ['Instagram', 'LinkedIn', 'Twitter/X']
const TONES = ['Profissional', 'Descontraído', 'Motivacional', 'Urgente', 'Educativo']

interface Post {
  platform: string
  content: string
  chars: number
}

const PLATFORM_COLORS: Record<string, string> = {
  Instagram: '#f58529',
  LinkedIn: '#0a66c2',
  'Twitter/X': '#1d9bf0',
}

const PLATFORM_ICONS: Record<string, string> = {
  Instagram: '📸',
  LinkedIn: '💼',
  'Twitter/X': '✖',
}

export default function Home() {
  const [business, setBusiness] = useState('')
  const [topic, setTopic] = useState('')
  const [platforms, setPlatforms] = useState<string[]>(['Instagram'])
  const [tone, setTone] = useState('Profissional')
  const [loading, setLoading] = useState(false)
  const [posts, setPosts] = useState<Post[]>([])
  const [error, setError] = useState('')
  const [copied, setCopied] = useState<string | null>(null)
  const [genCount, setGenCount] = useState(0)

  const FREE_LIMIT = 3

  function togglePlatform(p: string) {
    setPlatforms(prev =>
      prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]
    )
  }

  async function generate() {
    if (genCount >= FREE_LIMIT) return
    if (!business.trim() || !topic.trim() || platforms.length === 0) {
      setError('Preencha o negócio, o assunto e selecione ao menos uma rede.')
      return
    }
    setError('')
    setLoading(true)
    setPosts([])

    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ business, topic, platforms, tone }),
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setPosts(data.posts)
      setGenCount(c => c + 1)
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Erro ao gerar posts. Tente novamente.')
    } finally {
      setLoading(false)
    }
  }

  async function copyPost(content: string, platform: string) {
    await navigator.clipboard.writeText(content)
    setCopied(platform)
    setTimeout(() => setCopied(null), 2000)
  }

  const remaining = FREE_LIMIT - genCount

  return (
    <main className={styles.main}>
      {/* Header */}
      <header className={styles.header}>
        <div className={styles.logo}>
          <span className={styles.logoMark}>✦</span>
          <span className={styles.logoText}>PostAI</span>
        </div>
        <nav className={styles.nav}>
          <a href="#pricing" className={styles.navLink}>Preços</a>
          <button className={styles.ctaSmall}>Assinar agora</button>
        </nav>
      </header>

      {/* Hero */}
      <section className={styles.hero}>
        <div className={styles.badge}>✦ Powered by Claude AI</div>
        <h1 className={styles.heroTitle}>
          Posts que vendem,<br />
          <em>em segundos.</em>
        </h1>
        <p className={styles.heroSub}>
          Descreva seu negócio, escolha a plataforma e deixe a IA fazer o trabalho pesado.
        </p>
      </section>

      {/* App */}
      <section className={styles.appSection}>
        <div className={styles.formCard}>

          {/* Business */}
          <div className={styles.field}>
            <label className={styles.fieldLabel}>Seu negócio ou produto</label>
            <textarea
              className={styles.textarea}
              value={business}
              onChange={e => setBusiness(e.target.value)}
              placeholder="Ex: Sou personal trainer e vendo planos de treino online para iniciantes que querem emagrecer..."
              rows={3}
            />
          </div>

          {/* Topic */}
          <div className={styles.field}>
            <label className={styles.fieldLabel}>Assunto do post</label>
            <input
              className={styles.input}
              value={topic}
              onChange={e => setTopic(e.target.value)}
              placeholder="Ex: promoção de fim de semana, dica de treino, depoimento de cliente..."
            />
          </div>

          {/* Platforms */}
          <div className={styles.field}>
            <label className={styles.fieldLabel}>Redes sociais</label>
            <div className={styles.toggleGroup}>
              {PLATFORMS.map(p => (
                <button
                  key={p}
                  className={`${styles.toggleBtn} ${platforms.includes(p) ? styles.toggleBtnActive : ''}`}
                  onClick={() => togglePlatform(p)}
                  style={platforms.includes(p) ? { borderColor: PLATFORM_COLORS[p], color: PLATFORM_COLORS[p] } : {}}
                >
                  {PLATFORM_ICONS[p]} {p}
                </button>
              ))}
            </div>
          </div>

          {/* Tone */}
          <div className={styles.field}>
            <label className={styles.fieldLabel}>Tom de voz</label>
            <div className={styles.toggleGroup}>
              {TONES.map(t => (
                <button
                  key={t}
                  className={`${styles.toggleBtn} ${tone === t ? styles.toneActive : ''}`}
                  onClick={() => setTone(t)}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {error && <p className={styles.error}>{error}</p>}

          {/* CTA */}
          {genCount < FREE_LIMIT ? (
            <button
              className={styles.generateBtn}
              onClick={generate}
              disabled={loading}
            >
              {loading ? (
                <span className={styles.loader} />
              ) : (
                <>✦ Gerar posts — {remaining} restante{remaining !== 1 ? 's' : ''} grátis</>
              )}
            </button>
          ) : (
            <div className={styles.limitBox}>
              <p>🔒 Você usou todas as gerações gratuitas</p>
              <button className={styles.upgradeBtn}>Ver planos de assinatura ↗</button>
            </div>
          )}
        </div>

        {/* Results */}
        {posts.length > 0 && (
          <div className={styles.results}>
            {posts.map(post => (
              <div key={post.platform} className={`${styles.resultCard} fade-up`}>
                <div className={styles.resultHeader}>
                  <span
                    className={styles.platformBadge}
                    style={{ color: PLATFORM_COLORS[post.platform], borderColor: PLATFORM_COLORS[post.platform] + '44' }}
                  >
                    {PLATFORM_ICONS[post.platform]} {post.platform}
                  </span>
                  <div className={styles.resultMeta}>
                    <span className={styles.charCount}>{post.chars} chars</span>
                    <button
                      className={styles.copyBtn}
                      onClick={() => copyPost(post.content, post.platform)}
                    >
                      {copied === post.platform ? '✓ Copiado!' : 'Copiar'}
                    </button>
                  </div>
                </div>
                <p className={styles.postContent}>{post.content}</p>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Pricing */}
      <section className={styles.pricing} id="pricing">
        <h2 className={styles.sectionTitle}>Planos simples, sem surpresas</h2>
        <div className={styles.plansGrid}>
          {[
            { name: 'Grátis', price: 'R$0', period: 'para sempre', features: ['3 posts por dia', '3 plataformas', 'Todos os tons de voz'], cta: 'Começar grátis', highlight: false },
            { name: 'Básico', price: 'R$29', period: '/mês', features: ['30 posts por dia', '3 plataformas', 'Histórico de posts', 'Suporte por email'], cta: 'Assinar agora', highlight: true },
            { name: 'Pro', price: 'R$79', period: '/mês', features: ['Posts ilimitados', '3 plataformas', 'Agendamento', 'Múltiplos perfis', 'Suporte prioritário'], cta: 'Assinar Pro', highlight: false },
          ].map(plan => (
            <div key={plan.name} className={`${styles.planCard} ${plan.highlight ? styles.planCardHighlight : ''}`}>
              {plan.highlight && <div className={styles.popularBadge}>Mais popular</div>}
              <h3 className={styles.planName}>{plan.name}</h3>
              <div className={styles.planPrice}>
                <span className={styles.planAmount}>{plan.price}</span>
                <span className={styles.planPeriod}>{plan.period}</span>
              </div>
              <ul className={styles.planFeatures}>
                {plan.features.map(f => (
                  <li key={f} className={styles.planFeature}>✓ {f}</li>
                ))}
              </ul>
              <button className={`${styles.planCta} ${plan.highlight ? styles.planCtaHighlight : ''}`}>
                {plan.cta}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className={styles.footer}>
        <span className={styles.footerLogo}>✦ PostAI</span>
        <span className={styles.footerText}>Feito com Claude AI · {new Date().getFullYear()}</span>
      </footer>
    </main>
  )
}
